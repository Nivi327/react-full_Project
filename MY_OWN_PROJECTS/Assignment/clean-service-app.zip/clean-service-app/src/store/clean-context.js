import React from "react";

const cleanContext = React.createContext({
  faq: [],
  reviews: [],
  carouselImages: [],
});

export default cleanContext;
